Firmware variant compatibility
------------------------------

Honda CBR
---------
..0c....

Kawasaki ZX
-----------
..08.... models with gear position sensor
..0c.... models without gear position sensor
..10.... ZX14

Suzuki GSX, GSX-R, VZR, SV
--------------------------
..00....
..04.... with TRE (without gear position sensor)

Yamaha R1, R6, FJR
------------------
..0c.... R1, R6 with Yellow/Black RPM input
..14.... others

Aprilia RSV1000
---------------
..14....
..1c.... with ECU tacho output

Benelli
-------
..04....

Ducati
------
..14.... 1098

Triump Daytona 675
------------------
..10....

The dotted parts of the firmware variant are irrelevant.
