Verbose/debug firmware version compatibility
--------------------------------------------

Honda
-----
..4c....

Kawasaki
--------
..48.... models with gear position sensor
..4c.... models without gear position sensor

Suzuki
------
..40....
..44.... with TRE (without gear position sensor)

Yamaha
------
..54....


The dotted parts of the firmware variant are irrelevant.

